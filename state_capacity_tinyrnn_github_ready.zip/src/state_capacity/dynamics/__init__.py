"""Recurrent-dynamics analysis utilities."""

