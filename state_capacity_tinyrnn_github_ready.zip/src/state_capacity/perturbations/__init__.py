"""Artificial-agent perturbation utilities."""

