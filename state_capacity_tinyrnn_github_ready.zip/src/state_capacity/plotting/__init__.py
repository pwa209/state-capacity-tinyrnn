"""Journal figure plotting utilities."""

