"""TinyRNN model utilities."""

