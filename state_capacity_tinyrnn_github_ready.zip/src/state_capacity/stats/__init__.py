"""Statistical modeling utilities."""

